input_file_name = input()

print(f"Hello, {input_file_name}!")
