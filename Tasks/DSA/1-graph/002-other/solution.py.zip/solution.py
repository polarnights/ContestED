input_file_name = input()

print(f"Bye, {input_file_name}!")
